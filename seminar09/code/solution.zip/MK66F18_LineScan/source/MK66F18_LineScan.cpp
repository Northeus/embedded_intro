#include <array>
#include <string_view>
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"

template <uint32_t BASE, uint32_t PIN>
struct GPIO_Pin {
	static inline void set(bool value) {
		GPIO_PinWrite((GPIO_Type*) BASE, PIN, value);
	}

	static inline void toggle() {
		GPIO_PortToggle((GPIO_Type*) BASE, 1UL << PIN);
	}

	[[nodiscard]]
	static inline bool read() {
		return static_cast<bool>(GPIO_PinRead((GPIO_Type*) BASE, PIN));
	}
};

using GPIO_PinCLK = GPIO_Pin<GPIOB_BASE, BOARD_CAMERA_CLK_PIN>;
using GPIO_PinSI = GPIO_Pin<GPIOB_BASE, BOARD_CAMERA_SI_PIN>;

[[nodiscard]]
static inline uint16_t ADC_read_polling() {
	ADC16_SetChannelConfig(ADC1_PERIPHERAL, 0, &ADC1_channelsConfig[0]);

	while ((ADC16_GetChannelStatusFlags(ADC1_PERIPHERAL, 0)
			& kADC16_ChannelConversionDoneFlag) == 0) {
		asm ("nop");
	}

	return ADC16_GetChannelConversionValue(ADC1_PERIPHERAL, 0);
}

volatile bool elapsed = false;

extern "C" {
	void PIT_DELAY_IRQHANDLER(void) {
		PIT_StopTimer(PIT_PERIPHERAL, PIT_DELAY);

		uint32_t intStatus;

		intStatus = PIT_GetStatusFlags(PIT_PERIPHERAL, PIT_DELAY);
		PIT_ClearStatusFlags(PIT_PERIPHERAL, PIT_DELAY, intStatus);

		elapsed = true;

		#if defined __CORTEX_M && (__CORTEX_M == 4U)
		__DSB();
		#endif
	}
}

void delayUs(uint32_t us) {
	PIT_StopTimer(PIT_PERIPHERAL, PIT_DELAY);
	elapsed = false;

	PIT_SetTimerPeriod(PIT_PERIPHERAL, PIT_DELAY, us * 60);
	PIT_StartTimer(PIT_PERIPHERAL, PIT_DELAY);

	while (!elapsed) {
		asm ("nop");
	}
}

std::array<uint16_t, 128> readFrame() {
	std::array<uint16_t, 128> frame;

	GPIO_PinSI::set(1);
	GPIO_PinCLK::set(1);

	asm ("nop");
	GPIO_PinSI::set(0);

	for (auto &pixel : frame) {
		GPIO_PinCLK::set(0);

		asm ("nop");
		GPIO_PinCLK::set(1);

		pixel = ADC_read_polling();
	}

	GPIO_PinCLK::set(0);

	return frame;
}

std::array<uint16_t, 128> readCam(uint32_t exposition_us) {
	readFrame();

	delayUs(exposition_us);

	return readFrame();
}

// Encode 12-bit ADC value into a printable character
char encode(uint16_t adc_value) {
	constexpr std::string_view chars = "@#$1!:. ";

	uint32_t index = adc_value >> 9;

	return (0 <= index && index < chars.size()) ? chars.at(index) : '?';
}

int main(void) {
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    BOARD_InitDebugConsole();
#endif

    constexpr bool EXACT_DATA = true;
    constexpr bool ASK_EXPOSITION = false;

	uint32_t exposition_us = 5000;

    while(1) {
    	if (ASK_EXPOSITION) {
			PRINTF("Enter exposition in microseconds:\r\n");

			int scanned_numbers = SCANF("%u\r\n", &exposition_us);

			if (scanned_numbers != 1) {
				PRINTF("Invalid input!\r\n\r\n");
				continue;
			}
    	}

		PRINTF("Using exposition: %u (us)\r\n", exposition_us);

    	while (true) {
			for (const auto &pixel : readCam(exposition_us)) {
				if (EXACT_DATA) {
					PRINTF("%d ", pixel);
				} else {
					PUTCHAR(encode(pixel));
				}
			}

			PRINTF("\r\n");

			delayUs(2000000);
    	}
    }

    return 0 ;
}
